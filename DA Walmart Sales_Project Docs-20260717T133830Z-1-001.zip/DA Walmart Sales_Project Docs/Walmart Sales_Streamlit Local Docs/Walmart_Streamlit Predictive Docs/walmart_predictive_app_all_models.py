import streamlit as st
import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from math import sqrt

# -------------------- Page config --------------------
st.set_page_config(
    page_title="Walmart Sales – Predictive Analytics (Multiple Models)",
    layout="wide"
)

st.title("📈 Walmart Predictive Analytics – ML Model Comparison")
st.write(
    """
    Upload your cleaned Walmart dataset and compare predictions across **multiple ML models**
    used in your Jupyter notebook.

    **Included Models:**
    - Linear Regression  
    - Random Forest  
    - Gradient Boosting
    - Support Vector Regressor (SVR)
    """
)

# -------------------- Functions --------------------
@st.cache_data
def load_data(file):
    df = pd.read_csv(file)
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"])
    return df


def prepare_weekly(df, date_col, target_col):
    """
    Aggregate to weekly sales.
    """
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    ts = (
        df.groupby(pd.Grouper(key=date_col, freq="W"))[target_col]
          .sum()
          .reset_index()
    )
    ts.rename(columns={target_col: "Sales", date_col: "Date"}, inplace=True)
    ts = ts.sort_values("Date")
    return ts


def feature_engineer(df):
    """
    Add calendar features + time index.
    """
    df = df.copy()
    df["Year"] = df["Date"].dt.year
    df["Month"] = df["Date"].dt.month
    df["WeekOfYear"] = df["Date"].dt.isocalendar().week.astype(int)
    df["TimeIndex"] = np.arange(len(df))
    return df


def train_and_evaluate(df, model_name, test_size):
    """
    Time-based train/test split (no train_test_split) to avoid 'n_samples=1' errors.
    """
    df = df.copy()
    X = df[["Year", "Month", "WeekOfYear", "TimeIndex"]]
    y = df["Sales"].values

    n_samples = len(df)

    # ---- Safety checks to prevent your error ----
    if n_samples < 3:
        raise ValueError(
            f"Not enough weekly data points after aggregation: {n_samples}. "
            "You need at least 3 weeks of data to train + test."
        )

    # Compute split index manually (time-based, no shuffle)
    split_idx = int(np.floor(n_samples * (1 - test_size)))

    # Ensure at least 1 train and 1 test sample
    if split_idx < 1:
        split_idx = 1
    if split_idx >= n_samples:
        split_idx = n_samples - 1

    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]

    # ---- Choose model ----
    if model_name == "Linear Regression":
        model = LinearRegression()
    elif model_name == "Random Forest":
        model = RandomForestRegressor(n_estimators=300, random_state=42)
    elif model_name == "Gradient Boosting":
        model = GradientBoostingRegressor(random_state=42)
    elif model_name == "SVR":
        model = SVR(kernel="rbf")
    else:
        raise ValueError(f"Unknown model name: {model_name}")

    # ---- Fit & predict ----
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    metrics = {
        "MAE": mean_absolute_error(y_test, preds),
        "RMSE": sqrt(mean_squared_error(y_test, preds)),
        "MAPE %": np.mean(np.abs((y_test - preds) / (y_test + 1e-9))) * 100,
        "R² Score": r2_score(y_test, preds),
    }

    results_df = pd.DataFrame({
        "Date": df.loc[X_test.index, "Date"],
        "Actual": y_test,
        "Predicted": preds
    })

    return model, metrics, results_df


def forecast(model, df, weeks):
    """
    Simple forward forecast using calendar features.
    """
    df = df.copy()
    last_date = df["Date"].max()
    last_index = df["TimeIndex"].iloc[-1]

    future_dates = pd.date_range(last_date, periods=weeks + 1, freq="W")[1:]
    future = pd.DataFrame({"Date": future_dates})

    future["Year"] = future["Date"].dt.year
    future["Month"] = future["Date"].dt.month
    future["WeekOfYear"] = future["Date"].dt.isocalendar().week.astype(int)
    future["TimeIndex"] = np.arange(last_index + 1, last_index + 1 + weeks)

    features = future[["Year", "Month", "WeekOfYear", "TimeIndex"]]
    future["Forecast"] = model.predict(features)

    return future


# -------------------- Sidebar --------------------
st.sidebar.header("⚙️ Settings")

file = st.sidebar.file_uploader("Upload Cleaned Walmart CSV", type=["csv"])

model_selected = st.sidebar.selectbox(
    "Choose ML Model",
    ["Linear Regression", "Random Forest", "Gradient Boosting", "SVR"]
)

test_size = st.sidebar.slider("Test Size (%)", 10, 40, 20, 5) / 100
forecast_weeks = st.sidebar.slider("Forecast Weeks Ahead", 4, 24, 8, 2)

run_btn = st.sidebar.button("🚀 Run Model")


# -------------------- Main Execution --------------------
if not file:
    st.info("⬅ Upload your cleaned dataset to begin.")
    st.stop()

df = load_data(file)

st.subheader("📄 Raw Uploaded Data (sample)")
st.dataframe(df.head())

# Column Selection
st.subheader("1️⃣ Select columns")
date_col = st.selectbox("Select Date Column", df.columns.tolist(), index=df.columns.get_loc("Date") if "Date" in df.columns else 0)
target_col = st.selectbox("Select Target (Sales) Column", df.columns.tolist(), index=df.columns.get_loc("Total_Sales") if "Total_Sales" in df.columns else len(df.columns)-1)

# Weekly aggregation
st.subheader("2️⃣ Weekly Aggregated Sales")
ts = prepare_weekly(df, date_col, target_col)
st.write(f"Number of weekly data points after aggregation: **{len(ts)}**")
st.line_chart(ts.set_index("Date")["Sales"])

ts = feature_engineer(ts)

if run_btn:
    st.subheader(f"3️⃣ Model Results: {model_selected}")

    try:
        model, metrics, results = train_and_evaluate(ts, model_selected, test_size)

        # Display metrics
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("MAE", f"{metrics['MAE']:.2f}")
        col2.metric("RMSE", f"{metrics['RMSE']:.2f}")
        col3.metric("MAPE %", f"{metrics['MAPE %']:.2f}")
        col4.metric("R² Score", f"{metrics['R² Score']:.3f}")

        st.write("📈 Actual vs Predicted (Test Period)")
        st.dataframe(results)
        st.line_chart(results.set_index("Date")[["Actual", "Predicted"]])

        # Forecast
        st.subheader("4️⃣ Forecast")
        forecast_df = forecast(model, ts, forecast_weeks)
        st.dataframe(forecast_df)
        st.line_chart(forecast_df.set_index("Date")["Forecast"])

    except ValueError as e:
        # This will catch the "n_samples=1" type situation with a clear message
        st.error(str(e))
